document.querySelector('form').addEventListener('submit', function(event) {
    event.preventDefault();

    const name = document.getElementById('name').value;
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;

    console.log('Név:', name);
    console.log('E-mail:', email);
    console.log('Jelszó:', password);

    alert('Sikeres regisztráció!');
});
